import React from 'react'
import { ContactForm } from '../Components/ContactForm'

const ContactPage = () => {
  return (
    <>
      <ContactForm />
    </>
  )
}

export default ContactPage